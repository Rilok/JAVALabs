package nwd;

public interface Euclidean {
  int NWD(int a, int b);
}
