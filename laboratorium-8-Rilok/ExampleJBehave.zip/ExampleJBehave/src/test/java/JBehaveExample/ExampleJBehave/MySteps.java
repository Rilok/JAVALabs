package JBehaveExample.ExampleJBehave;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.jbehave.core.annotations.*;
public class MySteps{
	
	private Calculator test;
	
	@Given("Mam utworzony kolejny nowy kalkulator")
	public void givenMamUtworzonyKolejnyNowyKalkulator(){
		 test = new Calculator();
	}
	@When("dodam liczby 5 i 5")
	public void whenDodamLiczby5I5(){
		 test.setLeft(5);
		 test.setRight(5);
	}
	@Then("po dodaniu dostane 10")
	public void thenPoDodaniuDostane10(){
		 assertEquals(10,test.add(test.getLeft(), test.getRight()));
	}
}